import asyncio
import serial

class HCSR04Reader:
    def __init__(self, port="/dev/ttyACM0", baudrate=9600):
        self.serial_conn = serial.Serial(port, baudrate, timeout=1)
        self.data = {"jarak": None}

    async def read_distance(self):
        """ Membaca data dari sensor HC-SR04 melalui serial dengan asyncio """
        while True:
            try:
                # Jalankan operasi blocking di thread terpisah
                data = await asyncio.to_thread(self.serial_conn.readline)
                data = data.decode().strip()

                if data:
                    self.data["jarak"] = float(data)
                    print(f"Jarak: {self.data['jarak']} cm")

            except Exception as e:
                print(f"Error membaca data: {e}")

            await asyncio.sleep(1)  # Tunggu 1 detik sebelum membaca lagi

async def main():
    sensor = HCSR04Reader()
    await sensor.read_distance()

if __name__ == "__main__":
    asyncio.run(main())
