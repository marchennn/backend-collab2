import board
import adafruit_dht
import asyncio

class DHT22Sensor:
    def __init__(self, pin=board.D4):
        self.sensor = adafruit_dht.DHT22(pin)

    async def read_sensor_data(self):
        try:
            temperature_c = self.sensor.temperature
            humidity = self.sensor.humidity

            if temperature_c is None or humidity is None:
                raise ValueError("Failed to read from DHT22")

            return {"suhu": temperature_c, "kelembaban": humidity}

        except Exception as error:
            print(f"Error reading DHT22: {error}")
            return {"suhu": None, "kelembaban": None}
