import serial
import asyncio

class DFRobot_A02_Distance:
    STA_OK = 0x00
    STA_ERR_CHECKSUM = 0x01
    STA_ERR_SERIAL = 0x02
    STA_ERR_CHECK_OUT_LIMIT = 0x03
    STA_ERR_CHECK_LOW_LIMIT = 0x04
    STA_ERR_DATA = 0x05

    def __init__(self, port="/dev/ttyS0", baudrate=9600):
        self.serial_conn = serial.Serial(port, baudrate, timeout=1)
        self.distance = None
        self.last_operate_status = self.STA_OK
        self.distance_min = 0
        self.distance_max = 4500

    def set_dis_range(self, min_val, max_val):
        self.distance_min = min_val
        self.distance_max = max_val

    def read_distance(self):
        if self.serial_conn.in_waiting >= 4:
            data = self.serial_conn.read(4)
            if data[0] != 0xFF:
                return None

            if self._check_sum(data) == data[3]:
                self.distance = (data[1] << 8) | data[2]
                self.last_operate_status = self.STA_OK
                if self.distance > self.distance_max:
                    self.last_operate_status = self.STA_ERR_CHECK_OUT_LIMIT
                    self.distance = self.distance_max
                elif self.distance < self.distance_min:
                    self.last_operate_status = self.STA_ERR_CHECK_LOW_LIMIT
                    self.distance = self.distance_min
            else:
                self.last_operate_status = self.STA_ERR_CHECKSUM
        return self.distance

    def _check_sum(self, packet):
        return (packet[0] + packet[1] + packet[2]) & 0xFF

    async def read_sensor_data(self):
        """ Metode asinkron untuk membaca data """
        await asyncio.sleep(0.1)  # Delay kecil untuk non-blocking
        distance = self.read_distance()
        return {"a02yyuw_distance": distance} if distance is not None else {}
