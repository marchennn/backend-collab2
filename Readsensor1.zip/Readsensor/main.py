# main.py
import asyncio
from config.mqtt import mqtt_connector
from service.sensor import SensorService
from config import Config

async def main():
    await mqtt_connector.connect()
    await mqtt_connector.subscribe(Config.MQTT_TOPIC)
    try:
        while True:
            await SensorService.publish_sensor_data()
            await asyncio.sleep(5)
    except KeyboardInterrupt:
        print("Stopping program...")
    finally:
        await mqtt_connector.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
