import json
import asyncio
from config.mqtt import mqtt_connector  
from controller.dht2 import DHT22Sensor  
from controller.hcsr import HCSR04Reader  
from controller.a002yw import DFRobot_A02_Distance  

class SensorService:
    def __init__(self):
        self.dht22 = DHT22Sensor()
        self.hcsr04 = HCSR04Reader()
        self.a02yyuw = DFRobot_A02_Distance()  

    async def collect_sensor_data(self):
        dht_data, hcsr04_data, a02yyuw_data = await asyncio.gather(
            self.dht22.read_sensor_data(),
            self.hcsr04.read_distance(),
            self.a02yyuw.read_sensor_data()
        )

        sensor_data = {
            **dht_data,
            **hcsr04_data,
            **a02yyuw_data
        }
        return sensor_data

    async def publish_sensor_data(self):
        sensor_data = await self.collect_sensor_data()
        payload = json.dumps(sensor_data)
        await mqtt_connector.publish("sensor/data", payload)
        print(f"Published: {payload}")

    async def start(self):
        while True:
            await self.publish_sensor_data()
            await asyncio.sleep(5)  
