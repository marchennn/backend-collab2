import os
from dotenv import load_dotenv

load_dotenv(override=True)

class Config:
    MQTT_HOST = os.getenv("MQTT_HOST", "mqtt.example.com")
    MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
    MQTT_USERNAME = os.getenv("MQTT_USERNAME", "user")
    MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "password")
