# main.py
import sys
import os

# Menambahkan path direktori config ke sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'config')))

# Mengimpor Config dari __init__.py di dalam folder config
from __init__ import Config

# Menampilkan konfigurasi MQTT
print(Config.MQTT_HOST)
